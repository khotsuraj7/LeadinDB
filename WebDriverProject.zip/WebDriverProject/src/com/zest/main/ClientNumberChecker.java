package com.zest.main;


import java.util.ArrayList;
import java.util.List;

public class ClientNumberChecker {
    public static class ClientData {
        String name;
        String mobileNumber;
        String city;

        public ClientData(String name, String mobileNumber, String city) {
            this.name = name;
            this.mobileNumber = mobileNumber;
            this.city = city;
        }
    }

    public static void main(String[] args) {
        ClientData client1 = new ClientData("John", "1234567890", "New York");
        ClientData client2 = new ClientData("Jane", "0987654321", "Los Angeles");

        List<ClientData> clientDataList = new ArrayList<>();
        clientDataList.add(client1);
        clientDataList.add(client2);
    }
}
