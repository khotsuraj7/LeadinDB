package com.zest.main;


	import java.io.BufferedReader;
	import java.io.FileReader;
	import java.io.IOException;
	import java.util.ArrayList;
	import java.util.List;

	public class BulkDataProcessor {

	    public static void main(String[] args) {
	                                                                                       
	    	String dataDirectory = "path/to/data/files";                                    // Add the file path & Provide the path to the directory containing your data files

	        
	        List<ClientData> clientDataList = new ArrayList<>();                              // List to store client data                             // List to store client data

	        try {
	                                                                                          // Process each file in the data directory
	            for (int i = 1; i <= 100; i++) {                                             // Assuming files are named like txt format etc.
	                String fileName = "client_data_" + i + ".txt";
	                String filePath = dataDirectory + "/" + fileName;

	                
	                ClientData clientData = readClientDataFromFile(filePath);                 // Read data from the file and create a ClientData object

	                
	                clientDataList.add(clientData);                                            // Add the ClientData object to the list
	            }

	            

	                                                             
	            for (ClientData client : clientDataList) {                                           //Print the client data
	                System.out.println(client);
	            }

	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    private static ClientData readClientDataFromFile(String filePath) throws IOException {
	        
	        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
	            String line = reader.readLine();
	            String[] data = line.split(",");                                                               // Using each line in the file contains data separated by a delimiter (e.g., comma)

	            
	            return new ClientData(data[0], data[1], data[2]);                                               // Assuming data[0] is the name, data[1] is the mobile, and data[2] is the city
	        }
	    }

	    static class ClientData {
	        private final String name;
	        private final String mobile;
	        private final String city;

	        public ClientData(String name, String mobile, String city) {
	            this.name = name;
	            this.mobile = mobile;
	            this.city = city;
	        }

	        @Override
	        public String toString() {
	            return "ClientData{" +
	                    "name='" + name + '\'' +
	                    ", mobile='" + mobile + '\'' +
	                    ", city='" + city + '\'' +
	                    '}';
	        }
	    }
	}

