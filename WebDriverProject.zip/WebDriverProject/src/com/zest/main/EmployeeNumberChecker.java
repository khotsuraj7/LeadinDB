package com.zest.main;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class EmployeeNumberChecker {

	public static void main(String[] args) {
		
		
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\Suraj Khot\\Downloads\\chromedriver_win32\\chromedriver.exe");
		 
		 WebDriver driver = new ChromeDriver();
		 
		 driver.get("https://www.google.com/");
		 
		 
	        List<ClientData> clientDataList = List.of(
	        		new ClientData("John Doe", "1234567890", "US"),
	                new ClientData("ross", "9876543210", "USA")
	                );
	                
	                
	                // Add more data...
	        
	        
	        for (ClientData entry : clientDataList) {
	            
	            driver.findElement(By.name("name")).sendKeys(entry.getName());                                            // Fill in the form fields
	            driver.findElement(By.name("mobile")).sendKeys(entry.getMobile());
	            driver.findElement(By.name("city")).sendKeys(entry.getCity());

	            
	            driver.findElement(By.name("check_button")).click();                                                        // Simulate clicking a button to check uniqueness

	           
	            WebElement resultElement = driver.findElement(By.name("result"));                                                              // Extract and handle the result (whether the client number is unique or not)
	            String result = resultElement.getText();
	            System.out.println("Result for " + entry.getName() + " - " + entry.getMobile() + " - " + entry.getCity() + ": " + result);

	            
	            driver.findElement(By.name("name")).clear();                                                                                           // Clear the form for the next entry
	            driver.findElement(By.name("mobile")).clear();
	            driver.findElement(By.name("city")).clear();
	        }

	        
	        driver.quit();                                                                                                                             // Close the browser
	    }


		
	


		static class ClientData {
        private final String name;
        private final String mobile;
        private final String city;

        public ClientData(String name, String mobile, String city) {
            this.name = name;
            this.mobile = mobile;
            this.city = city;
        }
        
        public String getName() {
            return name;
        }

        public String getMobile() {
            return mobile;
        }

        public String getCity() {
            return city;
        }
       
	}

}
