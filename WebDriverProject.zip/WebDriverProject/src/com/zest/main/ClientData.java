package com.zest.main;

	
	import java.util.HashSet;
	import java.util.Scanner;

	public class ClientData {
	    private static HashSet<String> mobileNumbers = new HashSet<>();

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        while (true) {
	            System.out.println("Enter name (or 'exit' to quit):");
	            String name = scanner.nextLine();

	            if ("exit".equalsIgnoreCase(name)) {
	                break;
	            }

	            System.out.println("Enter mobile number (or 'back' to go back):");
	            String mobileNumber = scanner.nextLine();

	            if ("back".equalsIgnoreCase(mobileNumber)) {
	                System.out.println("Going back to name input...");
	                continue;
	            }

	            System.out.println("Enter city (or 'back' to go back):");
	            String city = scanner.nextLine();

	            if ("back".equalsIgnoreCase(city)) {
	                System.out.println("Going back to mobile number input...");
	                continue;
	            }

	            if (isMobileNumberUnique(mobileNumber)) {
	                System.out.println("Client data saved:");
	                System.out.println("Name: " + name);
	                System.out.println("Mobile number: " + mobileNumber);
	                System.out.println("City: " + city);
	                mobileNumbers.add(mobileNumber);
	            } else {
	                System.out.println("Mobile number already exists. Data not saved.");
	            }
	        }

	        scanner.close();
	    }

	    private static boolean isMobileNumberUnique(String mobileNumber) {
	        return !mobileNumbers.contains(mobileNumber);
	    }
	}


