# CRUD_RestAPI
Expose REST API which perform the Select/GET call , Insert/POST call , Delete/DELETE call , Update/POST call 
create a simple Students table in DB with (Id, name, mobileNo,emailId,presentAddress) fields and perform these curd operations and expose it as REST API 
using SpringBoot MySQL and Postman.

The files of code and Database Dumps file is added
