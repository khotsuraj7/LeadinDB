package com.springboot.service;

import com.springboot.web.dto.UserRegistration;

public interface UserService {
	User save(UserRegistration registration);
	
	

}
