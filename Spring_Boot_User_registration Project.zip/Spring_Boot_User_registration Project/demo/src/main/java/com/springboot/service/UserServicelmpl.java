package com.springboot.service;

import java.util.Arrays;

import com.springboot.web.dto.UserRegistration;

public class UserServicelmpl implements UserService {

	
	@Service
	public class UserServiceImpl implements  UserService{
		
		private UserRepositary userRepository;
		
		public UserServiceImpl(userRepository userRepository) {
			super();
			this.userRepository = userRepository;
		}
	}
	
	
	
	
	
	
	
	
	
	@Override
	public User save(UserRegistration registration) {
	    User user = new User(registration.getFirstName(),
	    		registration.getLastName(), registration.getEmail(), registration.password, Arrays.asList(new Role("ROLE USER")));
	    		
		return userRepository.save(user);
	}
	
	

}
