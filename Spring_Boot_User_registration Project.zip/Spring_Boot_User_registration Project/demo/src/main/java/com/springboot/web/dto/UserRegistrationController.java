package com.springboot.web.dto;

import com.springboot.service.UserService;

@Controller
@RequestMapping("/registration")
public class UserRegistrationController {
	
	private UserService userService;
	
	public UserRegistrationController(UserService userService) {
		
		super();
		this.userService = userService;
	}

	
	@GetMapping
	public String showRegistrationForm() {
		return "registration";
	}
	
	public String registerUserAccount(@ModelAttribute("User")UserRegistration registration);
	{
	userService.save(registration);
	return "redirect:/registration?sucess";
}

	
}
